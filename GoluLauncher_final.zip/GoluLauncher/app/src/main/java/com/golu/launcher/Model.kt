package com.golu.launcher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class AppItem(
    val label: String,
    val pkg: String,
    val image: ImageBitmap,
    val isBanner: Boolean,
    val intent: Intent
)

fun Drawable.toImage(): ImageBitmap {
    val w = intrinsicWidth.takeIf { it > 0 } ?: 256
    val h = intrinsicHeight.takeIf { it > 0 } ?: 256
    return toBitmap(w, h).asImageBitmap()
}

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    fun query(category: String) =
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(category), 0)

    val seen = HashSet<String>()
    val out = ArrayList<AppItem>()
    for (ri in query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER)) {
        val pkg = ri.activityInfo.packageName
        if (pkg == ctx.packageName || !seen.add(pkg)) continue
        val intent = pm.getLeanbackLaunchIntentForPackage(pkg)
            ?: pm.getLaunchIntentForPackage(pkg) ?: continue
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val banner = runCatching { ri.activityInfo.loadBanner(pm) }.getOrNull()
        val drawable = banner ?: ri.loadIcon(pm)
        val image = runCatching { drawable.toImage() }.getOrNull() ?: continue
        out += AppItem(ri.loadLabel(pm).toString(), pkg, image, banner != null, intent)
    }
    return out.sortedBy { it.label.lowercase() }
}

fun loadPhoto(ctx: Context): ImageBitmap? {
    val dir = ctx.getExternalFilesDir(null) ?: return null
    val f = listOf("wallpaper.jpg", "wallpaper.png").map { File(dir, it) }
        .firstOrNull { it.exists() } ?: return null
    val o = BitmapFactory.Options().apply { inSampleSize = 2 }
    return BitmapFactory.decodeFile(f.path, o)?.asImageBitmap()
}

data class Palette(
    val name: String,
    val c1: Color, val c2: Color, val c3: Color,
    val glow: Color,
    val bg: List<Color>
)

val Palettes = listOf(
    Palette("Aurora", Color(0xFF7C5CFF), Color(0xFF00E5C8), Color(0xFF4D7CFF), Color(0xFF8B6BFF),
        listOf(Color(0xFF05070F), Color(0xFF0A0B24), Color(0xFF120E3A))),
    Palette("Ocean", Color(0xFF2D9CFF), Color(0xFF18E0C0), Color(0xFF4F5BFF), Color(0xFF2D9CFF),
        listOf(Color(0xFF020D1A), Color(0xFF051A33), Color(0xFF0A2B52))),
    Palette("Sunset", Color(0xFFFF7A45), Color(0xFFFFB347), Color(0xFFFF3D8B), Color(0xFFFF7A45),
        listOf(Color(0xFF140606), Color(0xFF2A0E10), Color(0xFF40142A))),
    Palette("Emerald", Color(0xFF19E68C), Color(0xFF7CFF6B), Color(0xFF14C8D6), Color(0xFF19E68C),
        listOf(Color(0xFF021208), Color(0xFF06201A), Color(0xFF0A3024))),
    Palette("Rose", Color(0xFFFF5C8A), Color(0xFFC77DFF), Color(0xFFFF9AC1), Color(0xFFFF5C8A),
        listOf(Color(0xFF14060F), Color(0xFF2A0B1E), Color(0xFF3E1236))),
    Palette("Gold", Color(0xFFFFD740), Color(0xFFFF9100), Color(0xFFFFF176), Color(0xFFFFC107),
        listOf(Color(0xFF0F0B02), Color(0xFF1C1405), Color(0xFF2B1F08)))
)

val Styles = listOf("Orbs", "Stars", "Rain", "Aurora")

val LocalLite = compositionLocalOf { false }

fun Context.toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

fun decodePhoto(f: File): ImageBitmap? {
    val o = BitmapFactory.Options().apply { inSampleSize = 2 }
    return BitmapFactory.decodeFile(f.path, o)?.asImageBitmap()
}

fun autoPalette(hour: Int): Palette = when (hour) {
    in 6..16 -> Palettes[1]
    in 17..21 -> Palettes[2]
    else -> Palettes[0]
}

class GoluState(private val sp: SharedPreferences) {
    var favs by mutableStateOf(sp.getStringSet("favs", null)?.toSet() ?: emptySet())
    var hidden by mutableStateOf(sp.getStringSet("hidden", null)?.toSet() ?: emptySet())
    var locked by mutableStateOf(sp.getStringSet("locked", null)?.toSet() ?: emptySet())
    var order by mutableStateOf((sp.getString("order", "") ?: "").split(",").filter { it.isNotEmpty() })
    var themeIdx by mutableIntStateOf(sp.getInt("theme", 0))
    var styleIdx by mutableIntStateOf(sp.getInt("style", 0))
    var kids by mutableStateOf(sp.getBoolean("kids", false))
    var phone by mutableStateOf(sp.getBoolean("phone", false))
    var sound by mutableStateOf(sp.getBoolean("sound", true))
    var lite by mutableStateOf(sp.getBoolean("lite", false))
    var pin by mutableStateOf(sp.getString("pin", "") ?: "")
    var counts by mutableStateOf(
        sp.all.filterKeys { it.startsWith("cnt_") }
            .mapKeys { it.key.removePrefix("cnt_") }
            .mapValues { (it.value as? Int) ?: 0 }
    )
    val phoneKey: String = sp.getString("pkey", null)
        ?: (100000..999999).random().toString().also { sp.edit().putString("pkey", it).apply() }

    private fun saveSet(k: String, v: Set<String>) = sp.edit().putStringSet(k, HashSet(v)).apply()

    fun toggleFav(p: String) { favs = if (p in favs) favs - p else favs + p; saveSet("favs", favs) }
    fun toggleLock(p: String) { locked = if (p in locked) locked - p else locked + p; saveSet("locked", locked) }
    fun hide(p: String) { hidden = hidden + p; saveSet("hidden", hidden) }
    fun unhide(p: String) { hidden = hidden - p; saveSet("hidden", hidden) }
    fun setPin(v: String) { pin = v; sp.edit().putString("pin", v).apply() }

    fun bump(p: String) {
        val n = (counts[p] ?: 0) + 1
        counts = counts + (p to n)
        sp.edit().putInt("cnt_$p", n).apply()
    }

    fun sorted(apps: List<AppItem>): List<AppItem> =
        apps.sortedBy { a -> order.indexOf(a.pkg).let { if (it < 0) Int.MAX_VALUE else it } }

    fun move(pkg: String, delta: Int, row: List<String>, all: List<String>) {
        val i = row.indexOf(pkg)
        val j = i + delta
        if (i < 0 || j < 0 || j >= row.size) return
        val o = all.toMutableList()
        val a = o.indexOf(row[i])
        val b = o.indexOf(row[j])
        if (a < 0 || b < 0) return
        o[a] = row[j]; o[b] = row[i]
        order = o
        sp.edit().putString("order", o.joinToString(",")).apply()
    }

    // theme index == Palettes.size means "Auto" (changes by time of day)
    fun nextTheme() { themeIdx = (themeIdx + 1) % (Palettes.size + 1); sp.edit().putInt("theme", themeIdx).apply() }
    fun nextStyle() { styleIdx = (styleIdx + 1) % Styles.size; sp.edit().putInt("style", styleIdx).apply() }
    fun setKids(v: Boolean) { kids = v; sp.edit().putBoolean("kids", v).apply() }
    fun setPhone(v: Boolean) { phone = v; sp.edit().putBoolean("phone", v).apply() }
    fun setSound(v: Boolean) { sound = v; sp.edit().putBoolean("sound", v).apply() }
    fun setLite(v: Boolean) { lite = v; sp.edit().putBoolean("lite", v).apply() }

    private fun export(): String = JSONObject()
        .put("favs", JSONArray(favs.toList()))
        .put("hidden", JSONArray(hidden.toList()))
        .put("locked", JSONArray(locked.toList()))
        .put("order", JSONArray(order))
        .put("theme", themeIdx).put("style", styleIdx).put("sound", sound).put("lite", lite)
        .toString()

    private fun importJson(s: String) {
        val j = JSONObject(s)
        fun arr(k: String): List<String> = j.optJSONArray(k)?.let { a -> List(a.length()) { a.getString(it) } } ?: emptyList()
        favs = arr("favs").toSet(); hidden = arr("hidden").toSet()
        locked = arr("locked").toSet(); order = arr("order")
        themeIdx = j.optInt("theme", themeIdx); styleIdx = j.optInt("style", styleIdx)
        sound = j.optBoolean("sound", sound)
        lite = j.optBoolean("lite", lite)
        sp.edit().putStringSet("favs", HashSet(favs)).putStringSet("hidden", HashSet(hidden))
            .putStringSet("locked", HashSet(locked)).putString("order", order.joinToString(","))
            .putInt("theme", themeIdx).putInt("style", styleIdx).putBoolean("sound", sound).putBoolean("lite", lite).apply()
    }

    fun backup(ctx: Context): String = runCatching {
        File(ctx.getExternalFilesDir(null), "golu_backup.json").writeText(export())
        "Backup saved (golu_backup.json)"
    }.getOrElse { "Backup failed" }

    fun restore(ctx: Context): String {
        val f = File(ctx.getExternalFilesDir(null), "golu_backup.json")
        if (!f.exists()) return "No backup file found"
        return runCatching { importJson(f.readText()); "Settings restored" }.getOrElse { "Restore failed" }
    }
}
