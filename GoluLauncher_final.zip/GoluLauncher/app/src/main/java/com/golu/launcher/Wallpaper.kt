package com.golu.launcher

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

private fun DrawScope.orb(cx: Float, cy: Float, r: Float, c: Color) = drawCircle(
    brush = Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(cx, cy), radius = r),
    radius = r,
    center = Offset(cx, cy)
)

@Composable
fun GoluWallpaper(
    p: Palette,
    style: Int,
    photo: ImageBitmap?,
    showWord: Boolean = true,
    video: java.io.File? = null,
    shift: Float = 0f
) {
    val lite = LocalLite.current

    Canvas(Modifier.fillMaxSize()) { drawRect(Brush.verticalGradient(p.bg)) }

    if (video != null) {
        AndroidView(
            factory = { c ->
                android.widget.VideoView(c).apply {
                    setVideoPath(video.path)
                    setOnPreparedListener { mp -> mp.isLooping = true; mp.setVolume(0f, 0f) }
                    start()
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Color(0x66000000)))
    } else if (photo != null) {
        Image(photo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color(0x99000000)))
    }

    if (lite) {
        Canvas(Modifier.fillMaxSize()) {
            orb(size.width * 0.3f, size.height * 0.35f, size.minDimension * 0.8f, p.c1.copy(alpha = 0.35f))
            orb(size.width * 0.75f, size.height * 0.7f, size.minDimension * 0.85f, p.c2.copy(alpha = 0.28f))
        }
        if (showWord) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                BasicText(
                    "GOLU",
                    Modifier.offset(y = (-60).dp),
                    style = TextStyle(
                        color = Color(0x26FFFFFF), fontSize = 190.sp,
                        fontWeight = FontWeight.Black, letterSpacing = 36.sp
                    )
                )
            }
        }
        return
    }

    val sh by animateFloatAsState(shift, tween(700), label = "shift")
    val t = rememberInfiniteTransition(label = "bg")
    val p1 by t.animateFloat(0f, 1f,
        infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse), label = "p1")
    val p2 by t.animateFloat(0f, 1f,
        infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Reverse), label = "p2")
    val loop by t.animateFloat(0f, 1f,
        infiniteRepeatable(tween(5000, easing = LinearEasing), RepeatMode.Restart), label = "loop")
    val slow by t.animateFloat(0f, 1f,
        infiniteRepeatable(tween(40000, easing = LinearEasing), RepeatMode.Restart), label = "slow")
    val shimmer by t.animateFloat(0f, 1f,
        infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Restart), label = "shimmer")

    val stars = remember {
        val r = Random(7)
        List(70) { floatArrayOf(r.nextFloat(), r.nextFloat(), 1f + r.nextFloat() * 2.5f, r.nextFloat()) }
    }
    val drops = remember {
        val r = Random(3)
        List(60) { floatArrayOf(r.nextFloat(), r.nextFloat(), (1 + r.nextInt(3)).toFloat(), 14f + r.nextFloat() * 30f) }
    }
    val dust = remember {
        val r = Random(11)
        List(34) {
            floatArrayOf(r.nextFloat(), r.nextFloat(), (1 + r.nextInt(3)).toFloat(), 1.5f + r.nextFloat() * 3f, r.nextFloat())
        }
    }
    val tau = (2.0 * PI).toFloat()

    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val m = size.minDimension
        val sx = -sh * 8f
        when (style % 4) {
            0 -> {
                orb(w * (0.15f + 0.5f * p1) + sx, h * (0.25f + 0.25f * p2), m * 0.75f, p.c1.copy(alpha = 0.42f))
                orb(w * (0.85f - 0.45f * p2) + sx, h * (0.75f - 0.3f * p1), m * 0.85f, p.c2.copy(alpha = 0.34f))
                orb(w * (0.45f + 0.25f * p2) + sx, h * (0.15f + 0.1f * p1), m * 0.6f, p.c3.copy(alpha = 0.28f))
            }
            1 -> {
                orb(w * 0.5f + sx, h * 0.95f, m * 0.95f, p.c1.copy(alpha = 0.28f))
                orb(w * 0.15f, h * 0.2f, m * 0.5f, p.c3.copy(alpha = 0.15f))
                for (s in stars) {
                    val a = 0.2f + 0.8f * (0.5f + 0.5f * sin(tau * (loop + s[3])))
                    drawCircle(Color.White.copy(alpha = a), radius = s[2] * 1.6f, center = Offset(s[0] * w + sx * 0.5f, s[1] * h))
                }
            }
            2 -> {
                orb(w * 0.5f, h * 0.1f, m * 0.9f, p.c2.copy(alpha = 0.22f))
                for (d in drops) {
                    val y = ((d[1] + loop * d[2]) % 1f) * h
                    val x = d[0] * w
                    drawLine(p.c2.copy(alpha = 0.5f), Offset(x, y), Offset(x - 4f, y + d[3]), strokeWidth = 2f)
                }
            }
            else -> {
                val bands = listOf(Triple(0.28f, p.c1, 1), Triple(0.44f, p.c2, 2), Triple(0.58f, p.c3, 1))
                val steps = 48
                val amp = h * 0.07f
                val th = h * 0.26f
                bands.forEachIndexed { bi, (yy, col, n) ->
                    val path = Path()
                    val ph = slow * (bi + 1)
                    fun wave(i: Int) = h * yy + amp * sin(tau * (n * i / steps.toFloat() + ph)) + sx * 0.3f
                    path.moveTo(0f, wave(0))
                    for (i in 1..steps) path.lineTo(w * i / steps, wave(i))
                    for (i in steps downTo 0) path.lineTo(w * i / steps, wave(i) + th)
                    path.close()
                    drawPath(
                        path,
                        Brush.verticalGradient(
                            listOf(col.copy(alpha = 0f), col.copy(alpha = 0.38f), col.copy(alpha = 0f)),
                            startY = h * yy - amp,
                            endY = h * yy + amp + th
                        )
                    )
                }
            }
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        for (d in dust) {
            val y = (1f - ((d[1] + slow * d[2]) % 1f)) * size.height
            val x = d[0] * size.width + 14f * sin(tau * (slow * 2f + d[4]))
            val a = 0.10f + 0.22f * (0.5f + 0.5f * sin(tau * (slow * 3f + d[4])))
            drawCircle(Color.White.copy(alpha = a), radius = d[3], center = Offset(x, y))
        }
    }

    if (showWord) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            BasicText(
                "GOLU",
                modifier = Modifier
                    .offset(y = (-60).dp)
                    .graphicsLayer {
                        translationX = (p1 - 0.5f) * 40f - sh.coerceAtMost(12f) * 10f
                        compositingStrategy = CompositingStrategy.Offscreen
                    }
                    .drawWithContent {
                        drawContent()
                        val x = size.width * (-0.6f + shimmer * 2.2f)
                        drawRect(
                            Brush.linearGradient(
                                colors = listOf(Color(0x1AFFFFFF), Color(0x8CFFFFFF), Color(0x1AFFFFFF)),
                                start = Offset(x, 0f),
                                end = Offset(x + size.width * 0.6f, size.height * 0.4f)
                            ),
                            blendMode = BlendMode.SrcIn
                        )
                    },
                style = TextStyle(
                    color = Color.White,
                    fontSize = 190.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 36.sp
                )
            )
        }
    }
}
