package com.golu.launcher

import android.speech.tts.TextToSpeech
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun rememberClock(pattern: String): String {
    var s by remember { mutableStateOf("") }
    LaunchedEffect(pattern) {
        val f = SimpleDateFormat(pattern, Locale.getDefault())
        while (true) { s = f.format(Date()); delay(1000) }
    }
    return s
}

@Composable
fun MenuItem(text: String, pal: Palette, autoFocus: Boolean = false, center: Boolean = false, onClick: () -> Unit) {
    val fr = remember { FocusRequester() }
    var f by remember { mutableStateOf(false) }
    if (autoFocus) LaunchedEffect(Unit) { delay(120); runCatching { fr.requestFocus() } }
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (f) pal.glow.copy(alpha = 0.85f) else Color(0x22FFFFFF))
            .focusRequester(fr)
            .onFocusChanged { f = it.isFocused }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = if (center) Alignment.Center else Alignment.CenterStart
    ) {
        BasicText(text, style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium))
    }
}

@Composable
fun Chip(label: String, pal: Palette, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (f) 1.1f else 1f, spring(0.55f, 300f), label = "chip")
    Box(
        Modifier
            .graphicsLayer { scaleX = s; scaleY = s }
            .clip(RoundedCornerShape(50))
            .background(if (f) pal.glow.copy(alpha = 0.9f) else Color(0x33FFFFFF))
            .border(1.dp, if (f) Color(0xCCFFFFFF) else Color(0x33FFFFFF), RoundedCornerShape(50))
            .onFocusChanged { f = it.isFocused }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 9.dp)
    ) {
        BasicText(label, style = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium))
    }
}

@Composable
fun PinDialog(title: String, pal: Palette, onSubmit: (String) -> Boolean, onClose: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }
    fun press(d: String) {
        err = false
        if (pin.length < 4) pin += d
        if (pin.length == 4) {
            if (onSubmit(pin)) onClose() else { pin = ""; err = true }
        }
    }
    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier.width(320.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xF2101028)).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BasicText(title, style = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold))
            BasicText(
                (0 until 4).joinToString(" ") { if (it < pin.length) "●" else "○" },
                style = TextStyle(color = Color.White, fontSize = 28.sp)
            )
            if (err) BasicText("Wrong PIN, try again", style = TextStyle(color = Color(0xFFFF8A80), fontSize = 14.sp))
            listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9")).forEach { r ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    r.forEach { d ->
                        Box(Modifier.weight(1f)) { MenuItem(d, pal, autoFocus = d == "5", center = true) { press(d) } }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(1f)) { MenuItem("Del", pal, center = true) { pin = pin.dropLast(1) } }
                Box(Modifier.weight(1f)) { MenuItem("0", pal, center = true) { press("0") } }
                Box(Modifier.weight(1f)) { MenuItem("Esc", pal, center = true, onClick = onClose) }
            }
        }
    }
}

@Composable
fun SearchPanel(all: List<AppItem>, st: GoluState, pal: Palette, onLaunch: (AppItem) -> Unit, onClose: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(250); runCatching { fr.requestFocus() } }
    val res = if (q.isBlank()) emptyList()
    else all.filter { it.pkg !in st.hidden && it.label.contains(q, ignoreCase = true) }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxSize().background(Color(0xF0080818)).padding(40.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            BasicText("Search apps", style = TextStyle(color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 24.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.weight(1f).focusRequester(fr)
                        .clip(RoundedCornerShape(12.dp)).background(Color(0x22FFFFFF)).padding(16.dp)
                )
                Box(Modifier.width(140.dp)) { MenuItem("Close", pal, onClick = onClose) }
            }
            if (q.isNotBlank() && res.isEmpty()) {
                BasicText("No app found", style = TextStyle(color = Color(0xAAFFFFFF), fontSize = 20.sp))
            }
            AppRow(res, pal, st.favs, st.locked, null, { _, _ -> }, { _, _ -> }) { a, _ -> onClose(); onLaunch(a) }
        }
    }
}

@Composable
fun BossPanel(st: GoluState, all: List<AppItem>, pal: Palette, onSetPin: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val label = TextStyle(color = Color(0xCCFFFFFF), fontSize = 16.sp)
    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier
                .width(560.dp)
                .heightIn(max = 620.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xF2101028))
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            BasicText("BOSS MODE", style = TextStyle(color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp))
            BasicText(ramText(ctx), style = label)
            BasicText(storageText(), style = label)
            MenuItem("Kids mode: ${if (st.kids) "ON" else "OFF"}", pal, autoFocus = true) { st.setKids(!st.kids) }
            MenuItem("Sound effects: ${if (st.sound) "ON" else "OFF"}", pal) { st.setSound(!st.sound) }
            MenuItem("Phone control: ${if (st.phone) "ON" else "OFF"}", pal) { st.setPhone(!st.phone) }
            if (st.phone) {
                BasicText(
                    "Open on phone (same Wi-Fi): http://${localIp()}:8765/?key=${st.phoneKey}",
                    style = TextStyle(color = pal.c2, fontSize = 16.sp)
                )
            }
            MenuItem(if (st.pin.isEmpty()) "Set app-lock PIN" else "Change app-lock PIN", pal) { onSetPin() }
            MenuItem("Backup settings", pal) { ctx.toast(st.backup(ctx)) }
            MenuItem("Restore settings", pal) { ctx.toast(st.restore(ctx)) }
            val hiddenApps = all.filter { it.pkg in st.hidden }
            BasicText(if (hiddenApps.isEmpty()) "No hidden apps" else "Hidden apps (select to unhide)", style = label)
            hiddenApps.forEach { a -> MenuItem("Unhide: ${a.label}", pal) { st.unhide(a.pkg) } }
            Spacer(Modifier.height(4.dp))
            MenuItem("Close", pal, onClick = onClose)
        }
    }
}

@Composable
fun ChatPanel(
    pal: Palette,
    apps: List<AppItem>,
    onLaunch: (AppItem) -> Unit,
    onTheme: () -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val msgs = remember { mutableStateListOf<Pair<String, String>>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var speak by remember { mutableStateOf(false) }
    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember { TextToSpeech(ctx) { s -> ttsReady = (s == TextToSpeech.SUCCESS) } }
    DisposableEffect(Unit) { onDispose { tts.stop(); tts.shutdown() } }
    LaunchedEffect(ttsReady) { if (ttsReady) runCatching { tts.language = Locale.getDefault() } }

    val listState = rememberLazyListState()
    val keyFile = File(ctx.getExternalFilesDir(null), "golu_ai_key.txt")
    val key = remember { if (keyFile.exists()) keyFile.readText().trim() else "" }

    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    fun local(q: String, reply: String) { msgs += "user" to q; msgs += "assistant" to reply }

    fun send() {
        val q = input.trim()
        if (q.isEmpty() || busy) return
        input = ""
        val lower = q.lowercase()
        val openWords = listOf("open", "khol", "chalu", "start", "play", "खोल", "चला")
        val hit = apps.firstOrNull { lower.contains(it.label.lowercase()) }
        if (hit != null && openWords.any { lower.contains(it) }) {
            local(q, "Opening ${hit.label}"); onLaunch(hit); return
        }
        if (lower.contains("theme")) { local(q, "Theme changed"); onTheme(); return }
        if (key.isEmpty()) return
        msgs += "user" to q
        busy = true
        scope.launch {
            val r = askClaude(key, msgs.toList())
            msgs += "assistant" to r
            busy = false
            if (speak && ttsReady) tts.speak(r, TextToSpeech.QUEUE_FLUSH, null, "golu")
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xF0080818)).padding(40.dp)) {
            BasicText("Golu AI", style = TextStyle(color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp))
            BasicText(
                "Try: \"open YouTube\" or \"change theme\"",
                style = TextStyle(color = Color(0x99FFFFFF), fontSize = 14.sp)
            )
            Spacer(Modifier.height(10.dp))
            if (key.isEmpty()) {
                BasicText(
                    "No API key found, so only commands work. Save your key in golu_ai_key.txt inside Android/data/com.golu.launcher/files/ (see README).",
                    style = TextStyle(color = Color(0xFFFFAB40), fontSize = 16.sp)
                )
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(msgs) { m ->
                    BasicText(
                        (if (m.first == "user") "You: " else "Golu: ") + m.second,
                        style = TextStyle(color = if (m.first == "user") pal.c2 else Color.White, fontSize = 20.sp)
                    )
                }
                if (busy) item { BasicText("Golu is thinking…", style = TextStyle(color = Color(0x99FFFFFF), fontSize = 18.sp)) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 22.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Color(0x22FFFFFF)).padding(16.dp)
                )
                Box(Modifier.width(130.dp)) { MenuItem("Send", pal) { send() } }
                Box(Modifier.width(170.dp)) { MenuItem("Speak: ${if (speak) "ON" else "OFF"}", pal) { speak = !speak } }
                Box(Modifier.width(130.dp)) { MenuItem("Close", pal, onClick = onClose) }
            }
        }
    }
}

@Composable
fun Saver(p: Palette, style: Int, photo: ImageBitmap?, slides: List<File>, video: File?) {
    val t = rememberInfiniteTransition(label = "saver")
    val dx by t.animateFloat(-90f, 90f,
        infiniteRepeatable(tween(30000, easing = LinearEasing), RepeatMode.Reverse), label = "dx")
    val dy by t.animateFloat(-60f, 60f,
        infiniteRepeatable(tween(41000, easing = LinearEasing), RepeatMode.Reverse), label = "dy")
    val clock = rememberClock("hh:mm")
    val slide by produceState<ImageBitmap?>(initialValue = null, slides) {
        if (slides.isNotEmpty()) {
            var i = 0
            while (true) {
                value = withContext(Dispatchers.IO) { decodePhoto(slides[i % slides.size]) }
                i++
                delay(8000)
            }
        }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (slides.isNotEmpty()) {
            Crossfade(targetState = slide, animationSpec = tween(1200), label = "slide") { b ->
                if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
            Box(Modifier.fillMaxSize().background(Color(0x44000000)))
        } else {
            GoluWallpaper(p, style, photo, showWord = false, video = video)
        }
        Box(Modifier.fillMaxSize().graphicsLayer { translationX = dx; translationY = dy }, contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                BasicText("GOLU", style = TextStyle(color = Color(0x99FFFFFF), fontSize = 150.sp, fontWeight = FontWeight.Black, letterSpacing = 30.sp))
                BasicText(clock, style = TextStyle(color = Color(0xCCFFFFFF), fontSize = 56.sp, fontWeight = FontWeight.Light))
            }
        }
    }
}
