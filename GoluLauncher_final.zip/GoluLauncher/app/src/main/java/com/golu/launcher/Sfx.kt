package com.golu.launcher

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin

object Sfx {
    @Volatile var on = true
    private const val RATE = 22050
    private var last = 0L

    private fun build(parts: List<Triple<Double, Int, Double>>): ShortArray {
        val out = ArrayList<Short>()
        for ((f, ms, vol) in parts) {
            val n = RATE * ms / 1000
            for (i in 0 until n) {
                val env = minOf(1.0, i / (n * 0.15), (n - i) / (n * 0.5))
                out.add((sin(2 * PI * f * i / RATE) * env * vol * Short.MAX_VALUE).toInt().toShort())
            }
        }
        return out.toShortArray()
    }

    private val moveBuf by lazy { build(listOf(Triple(1200.0, 28, 0.12))) }
    private val openBuf by lazy { build(listOf(Triple(660.0, 70, 0.2), Triple(990.0, 110, 0.2))) }
    private val menuBuf by lazy { build(listOf(Triple(520.0, 60, 0.18))) }

    private fun play(buf: ShortArray, gap: Long) {
        if (!on) return
        val now = System.currentTimeMillis()
        if (now - last < gap) return
        last = now
        thread(isDaemon = true) {
            runCatching {
                val t = AudioTrack(
                    AudioManager.STREAM_MUSIC, RATE, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, buf.size * 2, AudioTrack.MODE_STATIC
                )
                t.write(buf, 0, buf.size)
                t.play()
                Thread.sleep(buf.size * 1000L / RATE + 120)
                t.release()
            }
        }
    }

    fun move() = play(moveBuf, 70)
    fun open() = play(openBuf, 0)
    fun menu() = play(menuBuf, 0)
}
