package com.golu.launcher

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.KeyEvent as AKeyEvent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Calendar

private val Konami = listOf(
    AKeyEvent.KEYCODE_DPAD_UP, AKeyEvent.KEYCODE_DPAD_UP,
    AKeyEvent.KEYCODE_DPAD_DOWN, AKeyEvent.KEYCODE_DPAD_DOWN,
    AKeyEvent.KEYCODE_DPAD_LEFT, AKeyEvent.KEYCODE_DPAD_RIGHT
)

private fun Context.openSettings(action: String, pkg: String? = null) {
    try {
        val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (pkg != null) i.data = Uri.parse("package:$pkg")
        startActivity(i)
    } catch (e: Exception) {
        toast("Not available on this TV")
    }
}

@Composable
fun GoluLauncher() {
    val ctx = LocalContext.current
    val st = remember { GoluState(ctx.getSharedPreferences("golu", Context.MODE_PRIVATE)) }
    CompositionLocalProvider(LocalLite provides st.lite) { GoluHome(st) }
}

@Composable
fun GoluHome(st: GoluState) {
    val ctx = LocalContext.current
    var all by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var refresh by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf("") }
    var shiftIdx by remember { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf<Pair<AppItem, List<String>>?>(null) }
    var boss by remember { mutableStateOf(false) }
    var chat by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf(false) }
    var saver by remember { mutableStateOf(false) }
    var banner by remember { mutableStateOf<String?>(null) }
    var launching by remember { mutableStateOf<Pair<AppItem, Rect>?>(null) }
    var pinReq by remember { mutableStateOf<Pair<String, (String) -> Boolean>?>(null) }
    var lastTouch by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val seq = remember { mutableListOf<Int>() }
    val first = remember { FocusRequester() }

    val hour by produceState(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        while (true) { value = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); delay(60_000) }
    }
    val auto = st.themeIdx >= Palettes.size
    val pal = if (auto) autoPalette(hour) else Palettes[st.themeIdx]
    val night = auto && (hour >= 22 || hour < 6)

    val extDir = remember { ctx.getExternalFilesDir(null) }
    val video = remember { File(extDir, "wallpaper.mp4").takeIf { it.exists() } }
    val slides = remember {
        File(extDir, "slideshow").listFiles()
            ?.filter { it.extension.lowercase() in listOf("jpg", "jpeg", "png") }
            ?.sortedBy { it.name } ?: emptyList()
    }
    val photo by produceState<ImageBitmap?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { loadPhoto(ctx) }
    }
    val weather by produceState(initialValue = "") {
        while (true) { value = fetchWeather() ?: value; delay(30 * 60 * 1000L) }
    }

    BackHandler(enabled = true) { }

    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { refresh++ }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        }
        ctx.registerReceiver(receiver, filter)
        onDispose { ctx.unregisterReceiver(receiver) }
    }

    LaunchedEffect(refresh) {
        all = withContext(Dispatchers.Default) { loadApps(ctx) }
        currentApps = all
    }
    LaunchedEffect(st.sound) { Sfx.on = st.sound }
    LaunchedEffect(Unit) { sayHook = { m -> banner = m } }
    LaunchedEffect(banner) { if (banner != null) { delay(6000); banner = null } }
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            if (!saver && System.currentTimeMillis() - lastTouch > 180_000) saver = true
        }
    }
    LaunchedEffect(st.phone) { if (st.phone) PhoneServer.start(ctx, st.phoneKey) else PhoneServer.stop() }

    LaunchedEffect(launching) {
        val l = launching ?: return@LaunchedEffect
        delay(330)
        runCatching { ctx.startActivity(l.first.intent) }
        delay(900)
        launching = null
    }

    fun openApp(a: AppItem, r: Rect?) {
        st.bump(a.pkg)
        Sfx.open()
        if (st.lite || r == null) runCatching { ctx.startActivity(a.intent) }
        else launching = a to r
    }
    fun launch(a: AppItem, r: Rect?) {
        if (a.pkg in st.locked && st.pin.isNotEmpty()) {
            pinReq = "Enter PIN" to { p: String -> if (p == st.pin) { openApp(a, null); true } else false }
        } else openApp(a, r)
    }

    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.lowercase()
        if (said != null) {
            val hit = all.firstOrNull { said.contains(it.label.lowercase()) }
            when {
                said.contains("theme") -> st.nextTheme()
                said.contains("style") -> st.nextStyle()
                said.contains("search") -> search = true
                hit != null -> launch(hit, null)
                else -> ctx.toast("No app found for: $said")
            }
        }
    }

    val visible = st.sorted(all).filter { it.pkg !in st.hidden }
    val favList = visible.filter { it.pkg in st.favs }
    val usedList = visible.filter { (st.counts[it.pkg] ?: 0) > 0 }
        .sortedByDescending { st.counts[it.pkg] ?: 0 }.take(6)
    val topList = if (favList.isNotEmpty()) favList else usedList
    val topLabel = if (favList.isNotEmpty()) "FAVORITES" else "MOST USED"
    val showTop = !st.kids && topList.isNotEmpty()
    val mainList = if (st.kids && favList.isNotEmpty()) favList else visible

    LaunchedEffect(mainList.isNotEmpty()) {
        if (mainList.isNotEmpty()) { delay(200); runCatching { first.requestFocus() } }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onPreviewKeyEvent { e ->
                lastTouch = System.currentTimeMillis()
                val down = e.type == KeyEventType.KeyDown
                if (saver) {
                    if (down) saver = false
                    true
                } else if (launching != null) {
                    true
                } else {
                    if (down) {
                        seq.add(e.nativeKeyEvent.keyCode)
                        if (seq.size > Konami.size) seq.removeAt(0)
                        if (seq == Konami) { seq.clear(); boss = true }
                    }
                    false
                }
            }
    ) {
        GoluWallpaper(pal, st.styleIdx, photo, video = video, shift = shiftIdx.toFloat())
        if (night) Box(Modifier.fillMaxSize().background(Color(0x59000000)))

        Column(Modifier.fillMaxSize().padding(horizontal = 56.dp, vertical = 26.dp)) {
            TopBar(weather)
            Box(Modifier.weight(1f))
            Crossfade(targetState = selected, animationSpec = tween(250), label = "name") { name ->
                BasicText(name, Modifier.padding(start = 8.dp),
                    style = TextStyle(color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.SemiBold))
            }
            val onFocus: (String, Int) -> Unit = { n, i -> selected = n; shiftIdx = i; Sfx.move() }
            val onMenu: (AppItem, List<String>) -> Unit = { a, row -> Sfx.menu(); menu = a to row }
            val onGo: (AppItem, Rect) -> Unit = { a, r -> launch(a, r) }
            if (showTop) {
                SectionLabel(topLabel)
                AppRow(topList, pal, st.favs, st.locked, first, onFocus, onMenu, onGo)
                SectionLabel("ALL APPS")
                AppRow(mainList, pal, st.favs, st.locked, null, onFocus, onMenu, onGo)
            } else {
                AppRow(mainList, pal, st.favs, st.locked, first, onFocus, onMenu, onGo)
            }
            if (!st.kids) {
                val chips = listOf<Pair<String, () -> Unit>>(
                    "Wi-Fi" to { ctx.openSettings(Settings.ACTION_WIFI_SETTINGS) },
                    "Bluetooth" to { ctx.openSettings(Settings.ACTION_BLUETOOTH_SETTINGS) },
                    "Settings" to { ctx.openSettings(Settings.ACTION_SETTINGS) },
                    "Search" to { search = true },
                    "Voice" to {
                        try {
                            voice.launch(
                                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            )
                        } catch (e: ActivityNotFoundException) {
                            ctx.toast("Voice search isn't available on this TV")
                        }
                    },
                    "Theme: ${if (auto) "Auto" else pal.name}" to { st.nextTheme() },
                    "Style: ${Styles[st.styleIdx % Styles.size]}" to { st.nextStyle() },
                    "Motion: ${if (st.lite) "Light" else "Full"}" to { st.setLite(!st.lite) },
                    "Sound: ${if (st.sound) "ON" else "OFF"}" to { st.setSound(!st.sound) },
                    "Golu AI" to { chat = true }
                )
                LazyRow(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(chips) { _, c -> Chip(c.first, pal, c.second) }
                }
            }
        }

        banner?.let { m ->
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = 70.dp)
                    .clip(RoundedCornerShape(16.dp)).background(Color(0xEE14142A))
                    .padding(horizontal = 28.dp, vertical = 14.dp)
            ) { BasicText(m, style = TextStyle(color = Color.White, fontSize = 24.sp)) }
        }

        launching?.let { (a, r) -> LaunchOverlay(a, r, pal) }

        if (saver) Saver(pal, st.styleIdx, photo, slides, video)
    }

    menu?.let { (app, row) ->
        Dialog(onDismissRequest = { menu = null }) {
            Column(
                Modifier.width(340.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xF2101028)).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BasicText(app.label, style = TextStyle(color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold))
                MenuItem(if (app.pkg in st.favs) "Remove from favorites" else "Add to favorites", pal, autoFocus = true) {
                    st.toggleFav(app.pkg); menu = null
                }
                MenuItem("Hide app", pal) { st.hide(app.pkg); menu = null }
                MenuItem("Move right", pal) { st.move(app.pkg, +1, row, st.sorted(all).map { it.pkg }); menu = null }
                MenuItem("Move left", pal) { st.move(app.pkg, -1, row, st.sorted(all).map { it.pkg }); menu = null }
                MenuItem(if (app.pkg in st.locked) "Remove PIN lock" else "Lock with PIN", pal) {
                    menu = null
                    val isLocked = app.pkg in st.locked
                    if (st.pin.isEmpty()) {
                        pinReq = "Set a 4-digit PIN" to { p: String -> st.setPin(p); st.toggleLock(app.pkg); true }
                    } else if (isLocked) {
                        pinReq = "Enter PIN" to { p: String -> if (p == st.pin) { st.toggleLock(app.pkg); true } else false }
                    } else st.toggleLock(app.pkg)
                }
                MenuItem("App info", pal) { menu = null; ctx.openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, app.pkg) }
                MenuItem("Uninstall", pal) { menu = null; ctx.openSettings(Intent.ACTION_DELETE, app.pkg) }
                MenuItem("Cancel", pal) { menu = null }
            }
        }
    }

    if (search) SearchPanel(all, st, pal, { launch(it, null) }) { search = false }
    if (boss) BossPanel(st, all, pal,
        onSetPin = { pinReq = "Set new 4-digit PIN" to { p: String -> st.setPin(p); true } }) { boss = false }
    if (chat) ChatPanel(pal, visible, { launch(it, null) }, { st.nextTheme() }) { chat = false }
    pinReq?.let { (title, check) -> PinDialog(title, pal, check) { pinReq = null } }
}

@Composable
fun LaunchOverlay(app: AppItem, r: Rect, pal: Palette) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(330, easing = FastOutSlowInEasing)) }
    Canvas(Modifier.fillMaxSize()) {
        val t = p.value
        val l = lerp(r.left, 0f, t)
        val tp = lerp(r.top, 0f, t)
        val rt = lerp(r.right, size.width, t)
        val bt = lerp(r.bottom, size.height, t)
        val cr = lerp(18.dp.toPx(), 0f, t)
        drawRoundRect(
            Brush.linearGradient(listOf(pal.c1, pal.c3)),
            topLeft = Offset(l, tp),
            size = Size(rt - l, bt - tp),
            cornerRadius = CornerRadius(cr)
        )
        val a = 1f - 0.7f * t
        if (app.isBanner) {
            drawImage(
                app.image,
                dstOffset = IntOffset(l.toInt(), tp.toInt()),
                dstSize = IntSize((rt - l).toInt().coerceAtLeast(1), (bt - tp).toInt().coerceAtLeast(1)),
                alpha = a
            )
        } else {
            val s = lerp(64.dp.toPx(), 170.dp.toPx(), t).toInt()
            val cx = ((l + rt) / 2f).toInt()
            val cy = ((tp + bt) / 2f).toInt()
            drawImage(
                app.image,
                dstOffset = IntOffset(cx - s / 2, cy - s / 2),
                dstSize = IntSize(s, s),
                alpha = a
            )
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    BasicText(text, Modifier.padding(start = 8.dp, top = 4.dp),
        style = TextStyle(color = Color(0xAAFFFFFF), fontSize = 14.sp, letterSpacing = 3.sp))
}

@Composable
fun TopBar(weather: String) {
    val time = rememberClock("hh:mm a")
    val date = rememberClock("EEE, d MMM")
    val temp = weather.substringBefore("  ")
    val cond = if (weather.contains("  ")) weather.substringAfter("  ").trim() else ""
    val main = TextStyle(color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
    val sub = TextStyle(color = Color(0xAAFFFFFF), fontSize = 12.sp, letterSpacing = 1.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        BasicText("GOLU", style = TextStyle(color = Color.White.copy(alpha = 0.85f), fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (weather.isNotEmpty()) {
                Column(horizontalAlignment = Alignment.End) {
                    BasicText(temp, style = main)
                    if (cond.isNotEmpty()) BasicText(cond, style = sub)
                }
                Box(Modifier.width(1.dp).height(32.dp).background(Color(0x44FFFFFF)))
            }
            Column(horizontalAlignment = Alignment.End) {
                BasicText(time, style = main)
                BasicText(date, style = sub)
            }
        }
    }
}

@Composable
fun AppRow(
    apps: List<AppItem>,
    pal: Palette,
    favs: Set<String>,
    locked: Set<String>,
    firstFocus: FocusRequester?,
    onFocused: (String, Int) -> Unit,
    onMenu: (AppItem, List<String>) -> Unit,
    onLaunch: (AppItem, Rect) -> Unit
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(22.dp),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 26.dp, bottom = 12.dp)
    ) {
        itemsIndexed(apps, key = { _, a -> a.pkg }) { index, app ->
            AppTile(
                app, index, pal, app.pkg in favs, app.pkg in locked,
                if (index == 0) firstFocus else null,
                { onFocused(app.label, index) },
                { onMenu(app, apps.map { it.pkg }) },
                { r -> onLaunch(app, r) }
            )
        }
    }
}

@Composable
fun AppTile(
    app: AppItem,
    index: Int,
    pal: Palette,
    fav: Boolean,
    locked: Boolean,
    focusRequester: FocusRequester?,
    onFocused: () -> Unit,
    onMenu: () -> Unit,
    onLaunch: (Rect) -> Unit
) {
    val lite = LocalLite.current
    var focused by remember { mutableStateOf(false) }
    var longDone by remember { mutableStateOf(false) }
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val scale by animateFloatAsState(
        if (focused) 1.16f else 1f, spring(dampingRatio = 0.5f, stiffness = 260f), label = "scale")
    val glow by animateFloatAsState(if (focused) 1f else 0f, tween(320), label = "glow")
    val enter = remember { Animatable(if (lite) 1f else 0f) }
    val sweep = remember { Animatable(1f) }
    val pulse = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        if (!lite) {
            delay(minOf(index, 8) * 55L)
            enter.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
        } else enter.snapTo(1f)
    }
    LaunchedEffect(focused, lite) {
        if (focused && !lite) {
            sweep.snapTo(0f)
            sweep.animateTo(1f, tween(900))
            while (true) {
                pulse.animateTo(1f, tween(1000))
                pulse.animateTo(0f, tween(1000))
            }
        } else {
            pulse.snapTo(0f)
        }
    }
    val shape = RoundedCornerShape(18.dp)

    Box(
        modifier = Modifier
            .size(width = 208.dp, height = 117.dp)
            .onGloballyPositioned { bounds = it.boundsInRoot() }
            .graphicsLayer { alpha = enter.value; translationY = (1f - enter.value) * 48f }
            .offset(y = (-14f * glow).dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(
                (4f + 26f * glow + 8f * pulse.value).dp, shape,
                ambientColor = pal.glow, spotColor = pal.glow
            )
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF2A2A4F), Color(0xFF16162C))))
            .drawWithContent {
                drawContent()
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color(0x26FFFFFF), Color.Transparent),
                        endY = size.height * 0.5f
                    )
                )
                val p = sweep.value
                if (p > 0f && p < 1f) {
                    val x = -size.width * 0.6f + p * size.width * 2.2f
                    drawRect(
                        Brush.linearGradient(
                            listOf(Color.Transparent, Color(0x70FFFFFF), Color.Transparent),
                            start = Offset(x, 0f),
                            end = Offset(x + size.width * 0.5f, size.height * 0.5f)
                        )
                    )
                }
            }
            .border(if (focused) 2.dp else 1.dp, Color.White.copy(alpha = 0.12f + 0.8f * glow), shape)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocused() }
            .onPreviewKeyEvent { e ->
                val k = e.nativeKeyEvent
                val center = k.keyCode == AKeyEvent.KEYCODE_DPAD_CENTER || k.keyCode == AKeyEvent.KEYCODE_ENTER
                if (k.action == AKeyEvent.ACTION_DOWN && center && k.repeatCount == 0) longDone = false
                if (k.action == AKeyEvent.ACTION_DOWN &&
                    ((center && k.repeatCount == 1) || k.keyCode == AKeyEvent.KEYCODE_MENU)
                ) { longDone = true; onMenu(); true } else false
            }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                if (longDone) longDone = false else onLaunch(bounds)
            },
        contentAlignment = Alignment.Center
    ) {
        if (app.isBanner) {
            Image(app.image, app.label, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Image(app.image, app.label, Modifier.size(64.dp))
        }
        if (fav) {
            BasicText("★", Modifier.align(Alignment.TopEnd).padding(8.dp),
                style = TextStyle(color = Color(0xFFFFD740), fontSize = 18.sp))
        }
        if (locked) {
            BasicText("PIN", Modifier.align(Alignment.TopStart).padding(8.dp),
                style = TextStyle(color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp))
        }
    }
}
