package com.golu.launcher

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.text.TextUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Collections
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import kotlin.concurrent.thread

@Volatile var currentApps: List<AppItem> = emptyList()
@Volatile var sayHook: (String) -> Unit = {}

// Change these to your own city (default: Agra)
const val WEATHER_LAT = 27.18
const val WEATHER_LON = 78.01

private fun wmo(c: Int) = when (c) {
    0 -> "Clear"
    1, 2, 3 -> "Cloudy"
    45, 48 -> "Fog"
    in 51..67 -> "Rain"
    in 71..77 -> "Snow"
    in 80..82 -> "Showers"
    in 95..99 -> "Storm"
    else -> ""
}

suspend fun fetchWeather(): String? = withContext(Dispatchers.IO) {
    runCatching {
        val u = URL("https://api.open-meteo.com/v1/forecast?latitude=$WEATHER_LAT&longitude=$WEATHER_LON&current=temperature_2m,weather_code")
        val c = u.openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        val j = JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("current")
        "${Math.round(j.getDouble("temperature_2m"))}\u00B0C  ${wmo(j.getInt("weather_code"))}".trim()
    }.getOrNull()
}

suspend fun askClaude(key: String, history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
    runCatching {
        val arr = JSONArray()
        history.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 600)
            .put("system", "You are Golu AI, a friendly assistant on a TV. Keep answers short and reply in the user's language.")
            .put("messages", arr)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream.bufferedReader().readText()
        if (code !in 200..299) "Error $code: check your key / internet."
        else JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
    }.getOrElse { "Couldn't reach Golu AI. Check the internet." }
}

fun ramText(ctx: Context): String {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    return "RAM in use: ${(mi.totalMem - mi.availMem) / 1048576} / ${mi.totalMem / 1048576} MB"
}

fun storageText(): String {
    val s = StatFs(Environment.getDataDirectory().path)
    return "Storage free: ${s.availableBytes / 1048576} / ${s.totalBytes / 1048576} MB"
}

fun localIp(): String = runCatching {
    Collections.list(NetworkInterface.getNetworkInterfaces())
        .flatMap { Collections.list(it.inetAddresses) }
        .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress
}.getOrNull() ?: "TV-IP"

object PhoneServer {
    private var server: ServerSocket? = null

    fun start(ctx: Context, key: String) {
        if (server != null) return
        val app = ctx.applicationContext
        thread(isDaemon = true) {
            runCatching {
                val ss = ServerSocket(8765)
                server = ss
                while (true) {
                    val s = ss.accept()
                    thread(isDaemon = true) {
                        runCatching { handle(app, key, s) }
                        runCatching { s.close() }
                    }
                }
            }
            server = null
        }
    }

    fun stop() {
        runCatching { server?.close() }
        server = null
    }

    private fun page(body: String) =
        "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'>" +
        "<body style='background:#0b0820;color:#fff;font-family:sans-serif;padding:16px'>" +
        "<h2>GOLU remote</h2>$body</body>"

    private fun handle(ctx: Context, key: String, s: Socket) {
        val line = BufferedReader(InputStreamReader(s.getInputStream())).readLine() ?: return
        val path = line.split(" ").getOrNull(1) ?: "/"
        val uri = Uri.parse("http://h$path")
        val main = Handler(Looper.getMainLooper())
        val html = if (uri.getQueryParameter("key") != key) {
            page("<p>Wrong key. Open the link shown in Boss Mode on the TV.</p>")
        } else when (uri.path) {
            "/launch" -> {
                val app = currentApps.firstOrNull { it.pkg == uri.getQueryParameter("pkg") }
                if (app != null) main.post { runCatching { ctx.startActivity(app.intent) } }
                page("<p>Opened ${TextUtils.htmlEncode(app?.label ?: "app")}.</p><p><a style='color:#7C4DFF' href='/?key=$key'>Back</a></p>")
            }
            "/say" -> {
                val t = uri.getQueryParameter("text") ?: ""
                main.post { sayHook(t) }
                page("<p>Sent to TV.</p><p><a style='color:#7C4DFF' href='/?key=$key'>Back</a></p>")
            }
            else -> {
                val links = currentApps.joinToString("") {
                    "<p><a style='color:#00E5FF;font-size:20px' href='/launch?key=$key&pkg=${it.pkg}'>${TextUtils.htmlEncode(it.label)}</a></p>"
                }
                page("<form action='/say'><input type=hidden name=key value='$key'>" +
                    "<input name=text placeholder='Message for TV' style='width:70%;padding:10px'> " +
                    "<button style='padding:10px'>Send</button></form><hr>$links")
            }
        }
        s.getOutputStream().apply {
            write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\n\r\n$html").toByteArray())
            flush()
        }
    }
}
