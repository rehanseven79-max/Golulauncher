GOLU LAUNCHER (final) - build and use

BUILD
1. Install Android Studio, File > Open this folder, wait for Gradle sync.
2. Build > Build APK(s). APK: app/build/outputs/apk/debug/app-debug.apk
3. adb connect TV_IP:5555 ; adb install app-debug.apk
4. adb shell am start -n com.golu.launcher/.MainActivity
5. Optional default home: adb shell cmd package set-home-activity com.golu.launcher/.MainActivity

LOOK AND MOTION
- Themes: Aurora, Ocean, Sunset, Emerald, Rose, Gold, and Auto (Ocean by day, Sunset in the evening, Aurora at night).
- Styles: Orbs, Stars, Rain, Aurora (flowing light ribbons). Floating light dust runs in every style.
- Tiles slide in one after another at start; the focused tile lifts, glows and pulses; a light sweep crosses it.
- Opening an app: the tile grows to fill the screen (Apple TV style) and then the app starts.
- The GOLU wordmark has a light sweep and drifts slowly as you move along a row.
- Chip "Motion: Light" switches off heavy animation and the grow effect for slow TVs. Use it if the launcher feels laggy.

USING IT
- Long-press OK (or Menu key) on an app: favorite, hide, move, PIN lock, app info, uninstall.
- Bottom chips: Wi-Fi, Bluetooth, Settings, Search, Voice, Theme, Style, Motion, Sound, Golu AI.
- Top row shows Favorites; if you have none it shows Most used.
- Boss Mode: Up Up Down Down Left Right on the remote.
  Inside: RAM/storage, Kids mode, Sound, Phone control, app-lock PIN, Backup/Restore, unhide apps.
- Screensaver starts after 3 minutes without a key press.

FILES YOU CAN PUSH (folder: /sdcard/Android/data/com.golu.launcher/files/)
  wallpaper.jpg     photo wallpaper
  wallpaper.mp4     looping muted video wallpaper (short 1080p clip; heavy for weak TVs)
  slideshow/        photos for the screensaver slideshow
  golu_ai_key.txt   your API key for Golu AI (never stored inside the APK)
  golu_backup.json  created by Boss Mode > Backup settings
Example: adb push wallpaper.jpg /sdcard/Android/data/com.golu.launcher/files/wallpaper.jpg

WEATHER CITY: edit WEATHER_LAT / WEATHER_LON in Net.kt (default Agra).
PHONE CONTROL: turn on in Boss Mode, open the shown link on your phone (same Wi-Fi). Keep OFF when not needed.
